/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package adventuregame;

/**
 *
 * @author Georgy
 */
import java.util.Random;
import java.util.Scanner;

public class AdventureGamecopy {
    //main menu text
     Random randGen = new Random();
    static void Welcome(){
       
       System.out.println("Welcome To Journey to the Dungeon");
     System.out.println("This is a demo for the java project I will be making updates to this game in the future");
     System.out.println("Instructions:");
         System.out.println("Type the number of what action you wish to take");;
     System.out.println("Do you wish to play?");
     System.out.println("(1).Start");
     System.out.println("(2).leave");
        }
    static void ending(){
        System.out.println("Thanks for playing!");
        System.out.println("This is a demo and updates will come");
         System.exit(0);
    }

    //to continue a group of text
 
    public static void main(String[] args) {
          //Arrays
     String[] monstersList1 = {"Robin Goblin","Undead Bob","Spider Roy",};
     String[] monstersList2 ={"Mine Control Guard","Dwarf giant","Bob's Girlfriend"};
     String[] monstersList3 ={"Unknown Ninja","Steve","Mind Control Archer"};
     String[] miniBoss = {"Drax the Undying warrior"}; 
     String[] Boss = {"Skelly Heart The Skeleton King!"};
   
      // random num generator
      
        //Variables
        int playerHP=100;
        int playerDmg=5;
        int MBHP = 150;
        int MBDMG = 30;
         playerHP-=MBDMG;
         MBHP-=playerDmg;
        int goBack = 2;
        int keepsGoing = 0;
        //player Vari
     
     //monster Vari
    // int monsterHealth=40;
    // int monsterDmg=20;
        while(goBack==2){
         goBack-=2;
        Welcome();
        }
        //player user input
      Scanner Pinput = new Scanner(System.in);
      
     
    
     String answer = Pinput.nextLine();
    
     if(answer.equals("1")){
         
         System.out.println("You're a a normal village man who resides in Konota Village.");
         System.out.println("You have lived a normal life till now: Working,eating, sleeping and doing it all over again.");
         System.out.println("This was till an attack happen and the village was undersiege overnight.");
         System.out.println("After most of the guards in the village have failed to find and defeat the foe");
         System.out.println ("who wrecked havic on Konota Village");
         System.out.println("You decide to stop this menace yourself");
         System.out.println("While everyone may doubt you and with good reason");
         System.out.println("I mean seriously have you seen yourself lately sheesh");
         System.out.println("Either way you have now decided to go through the depths of the forest");
         System.out.println("To find the dungeon in which this creature which attacked your village lives");
         System.out.println("Your mission above everything else survive");
         System.out.println("Good Luck...");
         
          System.out.println("(1).Continue");
         System.out.println("(2).Back to menu");
         // if to do a continue button
        int answerInt = Pinput.nextInt();
        // choice to continue to game
         if(answerInt==1){
            System.out.println("You've traveled to the forest where the knights of Konota were last seen.");
            System.out.println("Now you discovered a path, a darken path left with few vision as only some");
            System.out.println("of the leaves on the trees made way for the piercing light of the sun.");
            System.out.println("As you went on guided by nothing but darkness you can whispers among the the bushes,");
            System.out.println("behind you, above you, everywhere there seems to be someone or mutiple things lingering by.");
            System.out.println("You run towards the path head on and the whispers get louder!");
            System.out.println("You ignore them all and continue to go forward fearing what will come if you are to be caught.");
            System.out.println("Finally you pass by two weird trees and now you hear nothing but slience...");
            System.out.println("You look around and see a cave infront of you with a dark rocky hall, yet a light shimmers at");
            System.out.println("the end.");
            System.out.println("Do you enter?");
            System.out.println("1.yesssss..." );
            System.out.println("2.nah I'm dipping");
            //choice to enter cave
            
           //enter or leave cave
           int cave = Pinput.nextInt();
            if(cave==1){
                
            System.out.println("You go in deeper! through the darkness and finally make it to where there is some");
            System.out.println("clarity. ");
            System.out.println("You have come accross a room where a well is at it's center and is ready for you to explore");
            
            System.out.println("choose now what you decide to choose:");
            System.out.println("1.Inspect room");
           
            
            int firstRoomChoices = Pinput.nextInt();
            if(firstRoomChoices==1){
                while(goBack ==3)
                    goBack-=3;
                System.out.println("You explore the room and find a corspe,a writing on the wall,a rock");
                
                System.out.println("Which do you see first?");
                
                System.out.println("1.corspe");
                System.out.println("2.writing");
                System.out.println("3.rock");
                
                    
                //secret room
               
                int inspectChoices = Pinput.nextInt();
                if(inspectChoices==1){
                    System.out.println("You check the corspe and find a notebook");
                    System.out.println("You skim through it and find out that the words translate what's on the wall");
                    System.out.println("You read through it and a mossy wall behind the well opens...");
                    System.out.println("You see another writing in this room and it says beware! ");
                    System.out.println("Next to it there is a lever.");
                    System.out.println("Do you open this ancient door");
                    System.out.println("1.Yes");
                    System.out.println("2.nah");
                   /*
                    int leverOfFate=Pinput.nextInt();
                    int gift = 50;
                    if(leverOfFate==1){
                         Random randGen = new Random();
                        if(randGen.nextInt(100)>gift){
                            int randDMG = randGen.nextInt(MBDMG);
                        System.out.println("You pull the lever and what comes is " + miniBoss[0] );
                        System.out.println("Who's woken me up!");
                        System.out.println("------------------------------------------------");
                        System.out.println("NAME: "+miniBoss[0]);
                        System.out.println("HP:"+MBHP);
                        System.out.println("DMG:"+MBDMG);
                        
                        while(MBHP>0){
                            System.out.println("------------------------------------------------");
                        System.out.println("NAME: "+miniBoss[0]);
                        System.out.println("HP:"+MBHP);
                        System.out.println("DMG:"+MBDMG);
                            System.out.println("------------------------------------------------");
                            System.out.println("Player:");
                            System.out.println("HP:"+playerHP);
                            System.out.println("DMG"+playerDmg);
                            System.out.println("1.fight");
                            System.out.println("2.dodge");
                            System.out.println("3.run");
                            System.out.println("");
                            System.out.println("------------------------------------------------");
                            String battleChoices = Pinput.nextLine();
                            if(battleChoices.equals("1")){
                                int PDMG = randGen.nextInt(playerDmg);
                                int MDMG = randGen.nextInt(MBDMG);
                                System.out.println("Both of you enter battle and...");
                                System.out.println("DMG done to you:");
                                System.out.println("Total HP:");
                                System.out.println("DMG done to monster:");
                                System.out.println("Total HP of monster:");
                            }
                            else if(battleChoices.equals("2")){
                                
                            }
                            else if(battleChoices.equals("3")){
                                
                            }
                        }
                        
                        }
                        else {
                        System.out.print("You pull the lever and what comes is " );
                        playerDmg+=20;
                        System.out.println("+20 strength you upgraded!");
                        System.out.println("New Player DMG:"+playerDmg);
                        System.out.println("Full of strength your determination goes up and you go through the doors opened by the lever!");
                        ending();
                        System.out.println("Ending:Bravery");
                        }
                    }
                */
                   
                else if (inspectChoices==2){
                    
                    System.out.println("You choose to scan through writing, however you are unfamiliar with the words...");
                    System.out.println("You go back to inspecting");
                    goBack +=3;
            }
                //normal room
                else if (inspectChoices==3){
                    System.out.println("you found a rock maybe it would be good for testing how deep the well is.");
                    System.out.println("You drop it and find out that the well is deep since it took a while for the sound");
                    System.out.println("of the rock's fall took a while.");
                    System.out.print("Now you climb down carefully.");
                }
                
            }
            
            }
            
        
            else if(cave==2){
            System.out.println("You leave?");
            System.out.println("Well I didn't expect that...");
            System.out.println("You decide to leave ");
            System.out.println("You don't go through with it and go back the path and back to the village ");
            System.out.println("As you arrive back you are mocked by your quick return and are shamed by");
            System.out.println("the villagers and eventually you've had enough and leave to find a new home...");
            System.out.println("Ending: Left so soon?");
            ending();
         
     }        
            
         
        //choice to go back to menu
         else if (answerInt==2){
             System.out.println("Back");
             goBack +=2 ;
            //introStory();
            
         }
     
     else if (answer.equals("2")){
         System.out.println("Thanks for playing!");
         System.exit(0);
     }        
        
    }
     
        /*
            //PLANS FOR THE FUTuRE
         // boolean
          boolean gameStart =false;
          boolean menuStart = true;
     //While loop for the game to run
     while(menuStart){
    
     }
     Game:
     while (gameStart) {
         int randMonsterHealth = randGen.nextInt(monsterHealth);
         String monstersDisplay = monstersList1[randGen.nextInt(monstersList1.length)];
         System.out.println(monstersList1 +" has appeared!");
         while (monsterHealth > 0){
             System.out.println(monstersList1 +" HP: " + monsterHealth + "\n ");
             System.out.println("Player HP: "+ playerHealth);
             
         }
     }*/}
     
             
        }}}

